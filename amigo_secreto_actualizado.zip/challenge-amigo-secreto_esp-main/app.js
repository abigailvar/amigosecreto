
// Lista para almacenar los nombres
let nombres = [];

// Capturar elementos del DOM
const inputNombre = document.getElementById("nombre");
const listaNombres = document.getElementById("lista-nombres");
const resultado = document.getElementById("resultado");

// Función para agregar nombres
function adicionarNombre() {
    const nombre = inputNombre.value.trim();
    
    if (nombre === "") {
        alert("Por favor, ingresa un nombre válido.");
        return;
    }

    nombres.push(nombre);
    actualizarLista();
    inputNombre.value = ""; // Limpiar el campo de entrada
}

// Función para actualizar la lista de nombres en pantalla
function actualizarLista() {
    listaNombres.innerHTML = ""; // Limpiar lista antes de actualizar

    nombres.forEach(nombre => {
        const li = document.createElement("li");
        li.textContent = nombre;
        listaNombres.appendChild(li);
    });
}

// Función para sortear un amigo secreto
function sortearAmigo() {
    if (nombres.length === 0) {
        alert("Agrega al menos un nombre antes de sortear.");
        return;
    }

    const indiceAleatorio = Math.floor(Math.random() * nombres.length);
    const amigoSecreto = nombres[indiceAleatorio];

    resultado.textContent = "🎉 Amigo Secreto: " + amigoSecreto + " 🎉";
}

// Asignar funciones a los botones
document.getElementById("adicionar").addEventListener("click", adicionarNombre);
document.getElementById("sortear").addEventListener("click", sortearAmigo);
